using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gecenler : MonoBehaviour
{
    public List<GameObject> GecenlerList;
    void Start()
    {
        GecenlerList = new List<GameObject>();
    }
}
